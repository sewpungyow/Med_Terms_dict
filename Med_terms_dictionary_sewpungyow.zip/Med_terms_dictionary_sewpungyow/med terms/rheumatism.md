---
tags: [" #medterm "]
aliases: []
roots: [rheumat-, -ism]
definition:: chronic pain affecting joints and connective tissue
---
>[!note]+ Definition of rheumatism
>[[rhe-|rheumat-]][[-ism]] - chronic pain affecting joints and connective tissue
___
>[!info]+ Etymology of rheumatism
>originally thought to be caused by a flowing of the humors in the body