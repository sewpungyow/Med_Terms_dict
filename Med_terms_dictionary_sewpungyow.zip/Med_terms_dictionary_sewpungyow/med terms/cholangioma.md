---
tags: [" #medterm "]
aliases: []
roots: [chol-, angi-, -oma]
definition:: Bile duct tumor
---
>[!note]+ Definition of cholangioma
>[[chol-]][[angi-]][[-oma]] - Bile duct tumor
___
>[!info]+ Etymology of cholangioma

