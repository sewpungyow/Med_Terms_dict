---
tags: [" #medterm "]
aliases: []
roots: [ex-, fer-, -ent]
definition:: signals carried from the brain
---
>[!note]+ Definition of efferent
>[[ex-|ef-]][[fer-]][[-ent]] impulse - signals carried from the brain (bearing away)
___
>[!info]+ Etymology of efferent

