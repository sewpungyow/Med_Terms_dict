---
tags: [" #medterm "]
aliases: []
roots: [prot-, a-, op-, -ia]
definition:: color blindness to red
---
>[!note]+ Definition of protanopia
>[[prot-]][[a-|an-]][[op-]][[-ia]] - color blindness to red (the *first* of the primary colors) (condition of not seeing the first_)
___
>[!info]+ Etymology of protanopia
