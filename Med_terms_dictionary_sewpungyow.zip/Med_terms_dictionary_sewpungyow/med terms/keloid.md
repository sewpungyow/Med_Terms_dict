---
tags: [" #medterm "]
aliases: []
roots: [-cel-, -oid]
definition:: Scarlike growth of tissue on the skin
---
>[!note]+ Definition of keloid
>[[-cel-|kel-]][[-oid]] - scarlike growth of tissue on the skin (resembling tumor)
___
>[!info]+ Etymology of keloid

