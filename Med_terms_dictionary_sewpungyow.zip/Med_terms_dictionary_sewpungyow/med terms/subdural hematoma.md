---
tags: [" #medterm "]
aliases: []
roots: [sub-, dur-, -al, hemat-, -oma]
definition:: venous blood oozing into subdural space of the brain
---
>[!note]+ Definition of subdural hematoma
>[[sub-]][[dur-]][[-al]] [[hem-|hemat-]][[-oma]] - venous blood oozing into subdural (below the hard outer meninges) space of the brain (pertaining to blood swelling below dura)
>*see also: [[pachymeninx]]*
___
>[!info]+ Etymology of subdural hematoma

