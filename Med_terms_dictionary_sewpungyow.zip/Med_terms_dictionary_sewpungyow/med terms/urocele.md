---
tags: [" #medterm "]
aliases: []
roots: [ur-, -cel-, -e]
definition:: Accumulation of urine in scrotum
---
>[!note]+ Definition of urocele
>[[ur-]]o[[-cel-]][[-e]] - accumulation of urine (fluid) in scrotum (urine swelling)
___
>[!info]+ Etymology of urocele

