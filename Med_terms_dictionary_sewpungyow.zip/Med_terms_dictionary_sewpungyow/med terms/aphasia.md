---
tags: [" #medterm "]
aliases: []
roots: [a-, pha-, -sia]
definition:: Impaired ability to use or comprehend words
---
>[!note] Definition of aphasia
>[[a-]][[pha-]][[-ia|-sia]] - Impaired ability to use or comprehend words (condition of lacking communication)