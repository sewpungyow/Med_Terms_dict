---
tags: [" #medterm "]
aliases: []
roots: [hyper-, capn-, -ia]
definition:: too much CO2
---
>[!note]+ Definition of hypercapnia
>[[hyper-]][[capn-]][[-ia]] - too much CO2
___
>[!info]+ Etymology of hypercapnia

