---
tags: [" #medterm "]
aliases: []
roots: [galact-, -cel- ]
definition:: Milk-filled tumor
---
>[!note]+ Definition of galactocele
> [[gal-|galact-]]o[[-cel-]][[-e]] - Milk-filled tumor caused by obstruction of milk duct (milk tumor)
___
>[!info]+ Etymology of galactocele

