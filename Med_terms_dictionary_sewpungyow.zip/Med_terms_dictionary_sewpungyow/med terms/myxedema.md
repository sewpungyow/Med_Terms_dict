---
tags: [" #medterm "]
aliases: []
roots: [myx-, edema]
definition:: mucus swelling
---
>[!note]+ Definition of myxedema
>[[myx-]][[edema]] - mucus swelling of skin due to hypothyroidism ( mucus swelling)
___
>[!info]+ Etymology of myxedema

