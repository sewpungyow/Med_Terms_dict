---
tags: [" #medterm "]
aliases: []
roots: [a-, chlor-, hydr-, -ia]
definition:: Absence of HCl in stomach
---
>[!note] Definition of achlorhydria
>[[a-]][[chlor-]][[hydr-]][[-ia]] - Absence of HCl in stomach (condition of lacking {green water})

