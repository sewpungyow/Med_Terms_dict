---
tags: [" #medterm "]
aliases: []
roots: [ad-, fer-, -ent]
definition:: signals carried toward the brain
---
>[!note]+ Definition of afferent
>[[ad-|af-]][[fer-]][[-ent]] impulse - signals carried *toward* the brain (bearing towards)
___
>[!info]+ Etymology of afferent

