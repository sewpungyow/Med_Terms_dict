---
tags: [" #medterm "]
aliases: []
roots: [odont-, -agra]
definition:: toothache
---
>[!note]+ Definition of odontagra
>[[odont-]][[-agra]] - toothache, especially from gout (tooth pain)
___
>[!info]+ Etymology of odontagra

