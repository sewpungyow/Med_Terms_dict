---
tags: [" #medterm "]
aliases: []
roots: [ankyl-, chil-, -ia]
definition:: fusing of lips
---
>[!note]+ Definition of ankylochilia
[[ancyl-|ankyl-]]o-[[cheil-|chil-]][[-ia]] - fusing of lips (fusion of parts normally separate) (condition of lips fusing)
___
>[!info]+ Etymology of ankylochilia

