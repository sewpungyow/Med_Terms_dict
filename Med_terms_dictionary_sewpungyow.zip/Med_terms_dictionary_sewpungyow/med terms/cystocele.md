---
tags: [" #medterm "]
aliases: []
roots: [cyst-, -cel- ]
definition:: Bladder hernia
---
>[!note]+ Definition of cystocele
> [[cyst-]]o[[-cel-]][[-e]] - Bladder hernia
___
>[!info]+ Etymology of cystocele

