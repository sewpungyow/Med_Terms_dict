---
tags: [" #medterm "]
aliases: []
roots: [chol-, angi-, -itis]
definition:: inflammation of hepatic ducts or cystic duct
---
>[!note]+ Definition of cholangitis
>[[chol-]][[angi-]][[-itis]] - inflammation of hepatic bile ducts or cystic bile duct (inflammation of bile duct)
___
>[!info]+ Etymology of cholangitis

