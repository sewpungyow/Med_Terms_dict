---
tags: [" #medterm "]
aliases: []
roots: [erythr-, pen-, -ia]
definition:: decreased erythrocyte volume due to decreased hematocrit
---
>[!note]+ Definition of erythropenia
>[[erythr-]]o-[[pen-]][[-ia]] - decreased erythrocyte volume due to decreased hematocrit (condition of red blood cell deficiency)
___
>[!info]+ Etymology of erythropenia

