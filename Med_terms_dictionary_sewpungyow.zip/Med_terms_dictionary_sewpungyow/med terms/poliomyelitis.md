---
tags: [" #medterm "]
aliases: []
roots: [poli-, myel-, -itis]
definition:: inflammation of the gray matter of the spinal cord
---
>[!note]+ Definition of poliomyelitis
>[[poli-]]o-[[myel-]][[-itis]] - inflammation of the gray matter of the spinal cord 
___
>[!info]+ Etymology of poliomyelitis

