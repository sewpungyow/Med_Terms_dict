---
tags: [" #medterm "]
aliases: []
roots: [hemi-, crani-, -a ]
definition:: Pain on one side of the head
---
>[!note]+ Definition of migraine
> [[hemi-]][[crani-]][[-a]] - Pain on one side of the head (condition of half-skull [pain] )
___
>[!info]+ Etymology
>#greek hemikrania -> hemicrania (latin) -> emicránia (italian) -> migraine (french)


