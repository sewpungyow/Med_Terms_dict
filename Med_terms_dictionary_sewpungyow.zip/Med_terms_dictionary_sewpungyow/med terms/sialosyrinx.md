---
tags: [" #medterm "]
aliases: []
roots: [sial-, syring-]
definition:: fistula into salivary glands
---
>[!note]+ Definition of sialosyrinx
>[[sial-]]o-[[syring-|-syrinx]] - fistula into salivary glands (saliva fistula)
___
>[!info]+ Etymology of sialosyrinx

