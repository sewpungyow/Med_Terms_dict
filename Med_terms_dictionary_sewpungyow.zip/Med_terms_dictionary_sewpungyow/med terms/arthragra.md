---
tags: [" #medterm "]
aliases: []
roots: [arthr-, -agra]
definition:: acute joint paint
---
>[!note]+ Definition of arthragra
>[[arthr-]][[-agra]] - acute joint pain
___
>[!info]+ Etymology of arthragra

