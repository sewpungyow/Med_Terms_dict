---
tags: [" #medterm "]
aliases: []
roots: [arteri-, ven-, -ous]
definition:: Abnormal connection between artery and vein
---
>[!note]+ Definition of arteriovenous anastomosis
>[[arteri-]](o-)[[ven-]][[-ous]] [[anastomosis]] - Abnormal connection between artery and vein (abnormal opening back of artery and vein)
___
>[!info]+ Etymology of arteriovenous anastomosis


