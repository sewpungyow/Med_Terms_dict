---
tags: [" #medterm "]
aliases: []
roots: [ob-, capit-, -al]
definition:: back part of the head
---
>[!note]+ Definition of occipital
>[[ob-|oc-]][[capit-]][[-al]] - back part of the head (referring to back part of head)
___
>[!info]+ Etymology of occipital

