---
tags: [" #medterm "]
aliases: []
roots: [aur-, -cle]
definition:: portion of external ear not contained within the head
---
>[!note]+ Definition of auricle
>[[aur-]]i-[[-cle]] - portion of external ear not contained within the head (little ear)
___
>[!info]+ Etymology of auricle

