---
tags: [" #medterm "]
aliases: []
roots: [pneumon-, -ia]
definition:: inflammation of the lungs
---
>[!note]+ Definition of pneumonia
>[[pneumon-]][[-ia]] - inflammation of lungs (lung condition)
___
>[!info]+ Etymology of pneumonia

