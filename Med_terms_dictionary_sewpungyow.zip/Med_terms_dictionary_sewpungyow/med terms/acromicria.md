---
tags: [" #medterm "]
aliases: []
roots: [acr-, micr-, -ia]
definition:: abnormal smallness of the extremities
---
>[!note]+ Definition of acromicria
>[[acr-]]o-[[micr-]][[-ia]] - abnormal smallness of the extremities (condition of small extremities)
___
>[!info]+ Etymology of acromicria

