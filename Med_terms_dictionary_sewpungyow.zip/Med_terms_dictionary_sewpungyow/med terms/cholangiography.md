---
tags: [" #medterm "]
aliases: []
roots: [chol-, angi-, -graphy]
definition:: radiographic examination of hepatic bile ducts or cystic bile ducts
---
>[!note]+ Definition of cholangiography
>[[chol-]][[angi-]]o-[[-graphy]]- radiographic examination of hepatic bile ducts or cystic bile duct (recording of bile duct)
___
>[!info]+ Etymology of cholangiography

