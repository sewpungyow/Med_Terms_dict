---
tags: [" #medterm "]
aliases: []
roots: [ad-, duct-]
definition:: To draw towards an axis or the median line
---
>[!note] Definition of adduct
>[[ad-]][[duct-]] - To draw towards an axis or the median line (to bring toward)