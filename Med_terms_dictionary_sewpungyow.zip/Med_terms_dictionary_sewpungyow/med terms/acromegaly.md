---
tags: [" #medterm "]
aliases: []
roots: [acr-, mega-, -y]
definition:: abnormal enlargement of hands, feet, jaw, and/or other extrmities
---
>[!note]+ Definition of acromegaly
>[[acr-]]o-[[mega-|megal-]][[-y]] - abnormal enlargement of hands, feet, jaw, and/or other extremities, often due to too much GH ( condition of enlarged extremities)
___
>[!info]+ Etymology of acromegaly

