---
tags: [" #medterm "]
aliases: []
roots: [dys-, phor-, -ia]
definition:: sense of discomfort
---
>[!note]+ Definition of dysphoria
>[[dys-]][[phor-]][[-ia]] - sense of discomfort (condition bearing pain/abnormality)
___
>[!info]+ Etymology of dysphoria

