---
tags: [" #medterm "]
aliases: []
roots: [tel-, angi-, -osis]
definition:: abnormal capillary condition
---
>[!note]+ Definition of telangiosis
>[[tel-]][[angi-]][[-osis]] - abnormal capillary condition (abnormality in the ends of blood vessels)
___
>[!info]+ Etymology of telangiosis

