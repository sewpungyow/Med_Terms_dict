---
tags: [" #medterm "]
aliases: []
roots: [per-, tuss-, -is]
definition:: whooping cough
---
>[!note]+ Definition of pertussis
>[[per-]][[tuss-]][[-is]] - whooping cough (thorough cough)
___
>[!info]+ Etymology of pertussis

