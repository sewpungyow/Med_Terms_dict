---
tags: [" #medterm "]
aliases: []
roots: [ab-, duct-]
definition:: To draw away from an axis or the median plane
---
>[!note] Definition of abduct
>[[ab-]][[duct-]] - To draw away from an axis or the median plane (To bring away)