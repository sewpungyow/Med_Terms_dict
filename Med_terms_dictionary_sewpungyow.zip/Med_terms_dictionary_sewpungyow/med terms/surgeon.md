---
tags: [" #medterm "]
aliases: []
roots: [cheir-, ergon]
definition:: Physician who does surgeical procedures
---
>[!note]+ Definition of surgeon
>[[cheir-]][[erg-|ergon]] - Physician who does surgical procedures (hand work)
___
>[!info]+ Etymology of surgeon
>#greek cheirourgoun (v): to work with the hands -> surgeon

