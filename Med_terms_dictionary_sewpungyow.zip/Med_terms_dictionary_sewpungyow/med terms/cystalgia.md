---
tags: [" #medterm "]
aliases: []
roots: [cyst-, alg-, -ia]
definition:: Bladder pain
---
>[!note]+ Definition of cystalgia
>[[cyst-]][[alg-]][[-ia]] - Bladder pain (condition of pain of bladder)
___
>[!info]+ Etymology of cystalgia

