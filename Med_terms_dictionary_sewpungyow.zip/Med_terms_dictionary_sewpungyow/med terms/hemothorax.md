---
tags: [" #medterm "]
aliases: []
roots: [hem-, thorac-]
definition:: accumulation of blood within the pleura
---
>[!note]+ Definition of hemothorax
>[[hem-]]o-[[thorac-|thorax-]] - accumulation of blood within the [[pleur-]]a due to blood vessels rupturing (chest blood)
___
>[!info]+ Etymology of hemothorax

