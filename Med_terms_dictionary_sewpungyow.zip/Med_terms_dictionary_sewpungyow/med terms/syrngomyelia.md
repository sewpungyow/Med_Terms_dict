---
tags: [" #medterm "]
aliases: []
roots: [syring-, myel-, -ia]
definition:: cavities in tissues surrounding spinal cord
---
>[!note]+ Definition of syrngomyelia
>[[syring-]]o-[[myel-]][[-ia]] - cavities in tissues surrounding spinal cord (condition of spinal ord cavities)
___
>[!info]+ Etymology of syrngomyelia

