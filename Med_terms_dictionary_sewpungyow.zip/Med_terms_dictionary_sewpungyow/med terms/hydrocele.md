---
tags: [" #medterm "]
aliases: []
roots: [hydr-, -cel-, -e]
definition:: Accumulation of serous fluid in a saclike structure
---
>[!note]+ Definition of hydrocele
>[[hydr-]]o[[-cel-]][[-e]] - Accumulation of serous fluid in a saclike structure (fluid swelling)
___
>[!info]+ Etymology of hydrocele

