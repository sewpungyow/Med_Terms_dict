---
tags: [" #medterm "]
aliases: []
roots: [pachy-, mening- ]
definition:: dura mater
---
>[!note]+ Definition of pachymeninx
>[[pachy-]][[mening-|-meninx]] - dura mater (hard mother) outer tough membrane of brain and spinal cord (thick meninges)
___
>[!info]+ Etymology of pachymeninx
>- pia mater (devout mother) - inner of three meninges 
>- arachnoidea - middle of three meninges 
>- dura mater aka dura (hard mother) - outer of three meninges 

