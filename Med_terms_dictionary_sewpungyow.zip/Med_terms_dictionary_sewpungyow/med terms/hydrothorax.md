---
tags: [" #medterm "]
aliases: []
roots: [hydr-, thorac-]
definition:: accumulation of fluid within the pleura
---
>[!note]+ Definition of hydrothorax
>[[hydr-]]o-[[thorac-|thorax-]] - accumulation of fluid within the [[pleur-]]a (chest fluid)
___
>[!info]+ Etymology of hydrothorax

