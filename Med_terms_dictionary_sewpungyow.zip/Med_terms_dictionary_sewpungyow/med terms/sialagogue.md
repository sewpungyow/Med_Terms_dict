---
tags: [" #medterm "]
aliases: []
roots: [sial-, agog-]
definition:: agent that increases saliva flow
---
>[!note]+ Definition of sialagogue
>[[sial-]][[agog-|-agogue]] - agent that increases saliva flow
___
>[!info]+ Etymology of sialagogue

