---
tags: [" #medterm "]
aliases: []
roots: [erythr-, poie-, -sis]
definition:: erythrocyte formation
---
>[!note]+ Definition of erythropoiesis
>[[erythr-]]o-[[poie-]][[-sis]] - erythrocyte formation
___
>[!info]+ Etymology of erythropoiesis

