---
tags: [" #medterm "]
aliases: []
roots: [cyan-, op-, -ia]
definition:: seeing everything through a blue haze
---
>[!note]+ Definition of cyanopia
>[[cyan-]][[op-]][[-ia]] - seeing everything through a blue haze (condition of seeing blue)
___
>[!info]+ Etymology of cyanopia

