---
tags: [" #medterm "]
aliases: []
roots: [hypo-, hyp-, ox-, -ia]
definition:: Oxygen deficiency in tissue
---
>[!note] Definition of hypoxia
>[[hypo-|hyp-]][[ox-]][[-ia]] - Oxygen deficiency in tissue (condition of low oxygen)
