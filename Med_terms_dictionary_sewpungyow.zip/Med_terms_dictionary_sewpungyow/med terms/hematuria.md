---
tags: [" #medterm "]
aliases: []
roots: [hemat-, ur-, -ia]
definition:: blood in urine
---
>[!note]+ Definition of hematuria
>[[hem-|hemat-]][[ur-]][[-ia]] - blood in urine (condition of blood in urine)
___
>[!info]+ Etymology of hematuria


