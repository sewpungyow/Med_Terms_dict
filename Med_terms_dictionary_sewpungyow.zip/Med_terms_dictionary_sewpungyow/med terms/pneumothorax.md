---
tags: [" #medterm "]
aliases: []
roots: [pneumat-, thorac-]
definition:: air filling pleura
---
>[!note]+ Definition of pneumothorax
>[[pneumat-|pneum(at)-]]o-[[thorac-|thorax-]] - air filling [[pleur-]]al space due to perforation (chest air)
___
>[!info]+ Etymology of pneumothorax

