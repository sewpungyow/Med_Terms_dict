---
tags: [" #medterm "]
aliases: []
roots: [gastr-, -cel-, -e]
definition:: Stomach hernia
---
>[!note]+ Definition of gastrocele
>[[gastr-]]o[[-cel-]][[-e]] - Stomach hernia
___
>[!info]+ Etymology of gastrocele

