---
tags: [" #medterm "]
aliases: []
roots: [erythr-, op-, -ia]
definition:: see everything through a red haze
---
>[!note]+ Definition of erythropia
>[[erythr-]][[op-]][[-ia]] - see everything through a red haze (condition of seeing red)
___
>[!info]+ Etymology of erythropia

