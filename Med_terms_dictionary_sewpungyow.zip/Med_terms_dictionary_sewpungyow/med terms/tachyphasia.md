---
tags: [" #medterm "]
aliases: []
roots: [tachy-, pha-, -sia]
definition:: Rapid speech
---
>[!note] Definition of tachyphasia
>[[tachy-]][[pha-]][[-ia|-sia]] - Rapid speech (condition of speaking rapidly)