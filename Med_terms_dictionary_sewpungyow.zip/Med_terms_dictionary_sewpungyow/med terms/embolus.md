---
tags: [" #medterm "]
aliases: []
roots: [en-, bol-]
definition:: loding of a blockage-causing material within a blood vessel
---
>[!note]+ Definition of embolus
>[[en-|em-]][[bol-]]us - lodging of a blockage-causing material within a blood vessel (cast within)
>*see also: [[thromb-]]us*
___
>[!info]+ Etymology of embolus

