---
tags: [" #medterm "]
aliases: []
roots: [coli-, nephr-, -itis]
definition:: Inflammation of kidney caused by E. coli
---
>[!note]+ Definition of colinephritis
> [[col-|coli-]][[nephr-]][[-itis]] - Inflammation of kidney, caused by E. coli (kidney inflammation by E.coli)
___
>[!info]+ Etymology of colinephritis

