---
tags: [" #medterm "]
aliases: []
roots: [chol-, -doch-, lith-, -iasis]
definition:: gallstone obstructs the common bile duct
---
>[!note]+ Definition of choledocholithiasis
>[[chol-|chole-]][[-doch-]]o-[[lith-]][[-iasis]] - gallstone obstructs the common bile duct (stone in the bile duct disease)
___
>[!info]+ Etymology of choledocholithiasis

