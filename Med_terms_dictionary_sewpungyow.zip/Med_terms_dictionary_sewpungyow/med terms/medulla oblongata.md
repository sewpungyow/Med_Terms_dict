---
tags: [" #medterm "]
aliases: []
roots: [medull-]
definition:: lowest part of the brainstem
---
>[!note]+ Definition of medulla oblongata
>[[medull-]]a oblongata - lowest part of the brainstem (elongated marrow)
___
>[!info]+ Etymology of medulla oblongata

