---
tags: [" #medterm "]
aliases: []
roots: [ana-, stom-, -osis ]
definition:: Connection of two things normally diverging, Formation of passage between two normally distinct spaces or organs
---
>[!note]+ Definition of anastomosis
>[[ana-]][[stom-]][[-osis]] - 
>1. Connection of two things normally diverging (abnormal opening back [aka re-joining/re-opening])
>2. Formation of passage between two normally distinct spaces or organs 
___
>[!info]+ Etymology of anastomosis
>#greek

