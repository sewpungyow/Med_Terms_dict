---
tags: [" #medterm "]
aliases: []
roots: [tel-, angi-, -oma]
definition:: tumor made up of dilated capillaries
---
>[!note]+ Definition of telangioma
>[[tel-]][[angi-]][[-oma]] - tumor made up of dilated capillaries
___
>[!info]+ Etymology of telangioma

