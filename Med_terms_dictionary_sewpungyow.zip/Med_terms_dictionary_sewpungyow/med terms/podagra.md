---
tags: [" #medterm "]
aliases: []
roots: [pod-, -agra]
definition:: gout in the foot or large toe
---
>[!note]+ Definition of fpodagra
>[[pod-]][[-agra]] - gout in the foot or large toe
___
>[!info]+ Etymology of fpodagra

