---
tags: [" #medterm "]
aliases: []
roots: [semi-, capit-]
definition:: fore and upper part of the cranium
---
>[!note]+ Definition of sinciput
>[[semi-]][[capit-]] - fore and upper part of the cranium, upper half of the skull (half head)
___
>[!info]+ Etymology of sinciput

