---
tags: [" #medterm "]
aliases: []
roots: [an-, hydr-, -ous]
definition: Without water
---
>[!note] Definition of anhydrous
>[[a-|an-]][[hydr-]][[-ous]] - Without water
