---
tags: [" #medterm "]
aliases: []
roots: [myel-, -oma]
definition:: tumor originating in the bone marrow
---
>[!note]+ Definition of myeloma
>[[myel-]][[-oma]] - tumor originating in the bone marrow (bone marrow tumor)
___
>[!info]+ Etymology of myeloma

